from flask import Flask, request, jsonify
from flask_pymongo import PyMongo
from datetime import datetime
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Enable CORS for frontend requests

# Configure MongoDB
app.config["MONGO_URI"] = "mongodb://localhost:27017/food_sharing"
mongo = PyMongo(app)
donations_collection = mongo.db.donations  # Explicit collection reference

@app.route('/donate_food', methods=['POST'])
def donate_food():
    try:
        data = request.json
        print("Received data:", data)  # Debugging log

        if not data:
            return jsonify({"error": "Empty or invalid request"}), 400

        # Extract and validate data
        name = data.get("name")
        mobile = data.get("mobile")
        address = data.get("address")
        food_item = data.get("foodItem")
        prepared_time = data.get("preparedTime")
        event_proof = data.get("eventProof")

        if not all([name, mobile, address, food_item, prepared_time, event_proof]):
            return jsonify({"error": "Missing fields"}), 400

        # Convert prepared_time to datetime format
        try:
            prepared_time = datetime.fromisoformat(prepared_time)
        except ValueError:
            return jsonify({"error": "Invalid datetime format"}), 400

        # Insert into MongoDB
        donation = {
            "name": name,
            "mobile": mobile,
            "address": address,
            "foodItem": food_item,
            "preparedTime": prepared_time,
            "eventProof": event_proof
        }
        result = donations_collection.insert_one(donation)
        print("MongoDB Inserted ID:", result.inserted_id)  # Debugging log

        return jsonify({"message": "Food donation successful!", "id": str(result.inserted_id)}), 200

    except Exception as e:
        print("Error:", str(e))  # Print full error
        return jsonify({"error": str(e)}), 500

@app.route('/find_food', methods=['GET'])
def find_food():
    # Get city parameter, if provided.
    city = request.args.get('city', None)
    if city and city.strip():
        # If a city is provided, filter donations by address using a case-insensitive regex search.
        donations_cursor = donations_collection.find({"address": {"$regex": city, "$options": "i"}})
    else:
        # No city provided; return all donor details.
        donations_cursor = donations_collection.find()
    
    donations = []
    for donation in donations_cursor:
        donations.append({
            "name": donation.get("name"),
            "mobile": donation.get("mobile"),
            "address": donation.get("address"),
            "foodItem": donation.get("foodItem"),
            "preparedTime": donation.get("preparedTime").isoformat() if donation.get("preparedTime") else None,
            "eventProof": donation.get("eventProof")
        })
    return jsonify(donations)

@app.route('/')
def index():
    return "Welcome to the Food Sharing API!"

if __name__ == '__main__':
    app.run(debug=True)
