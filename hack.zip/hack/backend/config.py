MONGO_URI = "mongodb://localhost:27017/food_sharing"
UPLOAD_FOLDER = "uploads"
